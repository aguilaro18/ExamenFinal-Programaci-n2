import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { Session } from '@supabase/supabase-js';
import { AdministradorScreen } from '../screens/AdministradorScreen';
import { AccesoScreen } from '../screens/AccesoScreen';
import { EstudianteScreen } from '../screens/EstudianteScreen';
import { obtenerPerfil } from '../services/prestamos';
import { consumirRolEsperado, definirRolEsperado } from '../services/rolAcceso';
import { supabase } from '../services/supabase';
import type { PerfilUsuario } from '../models/Prestamo';
import type { RolUsuario } from '../services/supabase';
import { estilos } from '../theme/estilos';
import { colores } from '../theme/tokens';

const Stack = createNativeStackNavigator();

export function RootNavigator() {
  const [session, setSession] = useState<Session | null>(null);
  const [perfil, setPerfil] = useState<PerfilUsuario | null>(null);
  const [verificandoSesion, setVerificandoSesion] = useState(true);
  const [cargandoPerfil, setCargandoPerfil] = useState(false);
  const [errorPerfil, setErrorPerfil] = useState<string | null>(null);
  const [errorAcceso, setErrorAcceso] = useState<string | null>(null);

  useEffect(() => {
    let activo = true;
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_evento, nuevaSesion) => {
      if (activo) setSession(nuevaSesion);
    });

    supabase.auth.getSession().then(({ data, error }) => {
      if (!activo) return;
      if (error) setErrorPerfil(error.message);
      setSession(data.session);
      setVerificandoSesion(false);
    }).catch((error: unknown) => {
      if (activo) {
        setErrorPerfil(error instanceof Error ? error.message : 'No se pudo verificar la sesión');
        setVerificandoSesion(false);
      }
    });

    return () => {
      activo = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (verificandoSesion) return;
    if (!session) {
      setPerfil(null);
      setCargandoPerfil(false);
      return;
    }

    let activo = true;
    setCargandoPerfil(true);
    setErrorPerfil(null);
    obtenerPerfil(session.user.id).then(async (nuevoPerfil) => {
      if (!activo) return;
      const rolSolicitado = consumirRolEsperado();
      if (nuevoPerfil && rolSolicitado && nuevoPerfil.role !== rolSolicitado) {
        setPerfil(null);
        setErrorAcceso(rolSolicitado === 'admin'
          ? 'Esta cuenta no tiene permisos de administrador.'
          : 'Esta cuenta está registrada como administradora. Selecciona ese tipo de acceso.');
        const { error } = await supabase.auth.signOut();
        if (error && activo) setErrorPerfil(error.message);
        return;
      }
      setErrorAcceso(null);
      setPerfil(nuevoPerfil);
    }).catch((error: unknown) => {
      if (activo) setErrorPerfil(error instanceof Error ? error.message : 'No se pudo cargar el perfil');
    }).finally(() => {
      if (activo) setCargandoPerfil(false);
    });

    return () => { activo = false; };
  }, [session, verificandoSesion]);

  if (verificandoSesion || (session && cargandoPerfil)) {
    return (
      <SafeAreaView style={[estilos.pantalla, { alignItems: 'center', justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color={colores.primario} />
      </SafeAreaView>
    );
  }

  if (session && !perfil) {
    return (
      <SafeAreaView style={[estilos.pantalla, estilos.contenido, { justifyContent: 'center' }]}>
        <Text style={estilos.titulo}>No se pudo cargar tu perfil</Text>
        <Text style={estilos.error}>
          {errorPerfil ?? 'No encontramos tu perfil. Verifica que la base de datos de Supabase esté configurada.'}
        </Text>
        <Pressable style={estilos.boton} onPress={() => { void supabase.auth.signOut(); }}>
          <Text style={estilos.botonTexto}>Cerrar sesión</Text>
        </Pressable>
      </SafeAreaView>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {session && perfil ? (
          perfil.role === 'admin'
            ? <Stack.Screen name="Administrador">{() => <AdministradorScreen perfil={perfil} />}</Stack.Screen>
            : <Stack.Screen name="Estudiante">{() => <EstudianteScreen perfil={perfil} />}</Stack.Screen>
        ) : (
          <Stack.Screen name="Acceso">
            {() => (
              <AccesoScreen
                errorAcceso={errorAcceso}
                onRoleSelected={(role: RolUsuario) => {
                  setErrorAcceso(null);
                  definirRolEsperado(role);
                }}
              />
            )}
          </Stack.Screen>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
