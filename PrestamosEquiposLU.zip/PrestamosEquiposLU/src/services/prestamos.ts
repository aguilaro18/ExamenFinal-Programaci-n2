import type { Equipo, PerfilUsuario, Prestamo } from '../models/Prestamo';
import { supabase } from './supabase';

export async function obtenerPerfil(id: string): Promise<PerfilUsuario | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function listarEquipos(): Promise<Equipo[]> {
  const { data, error } = await supabase.from('equipment').select('*').order('name');
  if (error) throw new Error(error.message);
  return data;
}

export async function listarPrestamosEstudiante(id: string): Promise<Prestamo[]> {
  const { data, error } = await supabase
    .from('loans').select('*').eq('student_id', id).order('requested_at', { ascending: false });
  if (error) throw new Error(error.message);

  const equipoIds = [...new Set(data.map((prestamo) => prestamo.equipment_id))];
  if (equipoIds.length === 0) return data;

  const { data: equipos, error: errorEquipos } = await supabase
    .from('equipment').select('id, name').in('id', equipoIds);
  if (errorEquipos) throw new Error(errorEquipos.message);
  const nombres = new Map(equipos.map((equipo) => [equipo.id, equipo.name]));
  return data.map((prestamo) => ({
    ...prestamo,
    equipment: { name: nombres.get(prestamo.equipment_id) ?? 'Equipo' },
  }));
}

export async function listarPrestamosAdministrador(): Promise<Prestamo[]> {
  const { data, error } = await supabase.from('loans').select('*')
    .order('requested_at', { ascending: false });
  if (error) throw new Error(error.message);
  if (data.length === 0) return data;

  const estudianteIds = [...new Set(data.map((prestamo) => prestamo.student_id))];
  const equipoIds = [...new Set(data.map((prestamo) => prestamo.equipment_id))];
  const [estudiantes, equipos] = await Promise.all([
    supabase.from('profiles').select('id, full_name, carnet').in('id', estudianteIds),
    supabase.from('equipment').select('id, name').in('id', equipoIds),
  ]);
  if (estudiantes.error) throw new Error(estudiantes.error.message);
  if (equipos.error) throw new Error(equipos.error.message);

  const perfiles = new Map(estudiantes.data.map((perfil) => [perfil.id, perfil]));
  const nombres = new Map(equipos.data.map((equipo) => [equipo.id, equipo.name]));
  return data.map((prestamo) => ({
    ...prestamo,
    student: perfiles.get(prestamo.student_id),
    equipment: { name: nombres.get(prestamo.equipment_id) ?? 'Equipo' },
  }));
}

export async function solicitarPrestamo(equipoId: string): Promise<void> {
  const { error } = await supabase.rpc('request_loan', { p_equipment_id: equipoId });
  if (error) throw new Error(error.message);
}

export async function revisarPrestamo(
  prestamoId: string,
  decision: 'approved' | 'rejected',
): Promise<void> {
  const { error } = await supabase.rpc('review_loan', {
    p_loan_id: prestamoId,
    p_decision: decision,
  });
  if (error) throw new Error(error.message);
}

export async function marcarDevuelto(prestamoId: string): Promise<void> {
  const { error } = await supabase.rpc('return_loan', { p_loan_id: prestamoId });
  if (error) throw new Error(error.message);
}

export async function subirFotoPerfil(userId: string, uri: string): Promise<string> {
  const respuesta = await fetch(uri);
  if (!respuesta.ok) throw new Error('No se pudo leer la imagen seleccionada');
  const imagen = await respuesta.arrayBuffer();
  const ruta = `${userId}/${Date.now()}.jpg`;
  const { error } = await supabase.storage.from('avatars').upload(ruta, imagen, {
    contentType: 'image/jpeg',
    upsert: true,
  });
  if (error) throw new Error(error.message);
  return supabase.storage.from('avatars').getPublicUrl(ruta).data.publicUrl;
}
