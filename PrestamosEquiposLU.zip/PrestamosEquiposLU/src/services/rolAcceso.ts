import type { RolUsuario } from './supabase';

let rolEsperado: RolUsuario | null = null;

export function definirRolEsperado(rol: RolUsuario): void {
  rolEsperado = rol;
}

export function consumirRolEsperado(): RolUsuario | null {
  const rol = rolEsperado;
  rolEsperado = null;
  return rol;
}

export function limpiarRolEsperado(): void {
  rolEsperado = null;
}
