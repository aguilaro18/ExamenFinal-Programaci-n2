import * as ImagePicker from 'expo-image-picker';

export async function seleccionarFoto(): Promise<string | null> {
  const permiso = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permiso.granted) throw new Error('Permite el acceso a tus fotos para seleccionar una imagen.');

  const resultado = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.8,
  });
  return resultado.canceled ? null : resultado.assets[0]?.uri ?? null;
}
