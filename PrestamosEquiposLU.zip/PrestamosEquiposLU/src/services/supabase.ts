import { createClient } from '@supabase/supabase-js';
import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_KEY
  ?? process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

if (!url || !key) {
  throw new Error('Faltan las variables de Supabase en .env');
}

export const supabase = createClient<Database>(url, key, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export type RolUsuario = 'student' | 'admin';
export type EstadoPrestamo = 'pending' | 'approved' | 'rejected' | 'returned';

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          carnet: string;
          career: string;
          photo_url: string | null;
          role: RolUsuario;
          created_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          carnet: string;
          career: string;
          photo_url?: string | null;
          role?: RolUsuario;
          created_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          carnet?: string;
          career?: string;
          photo_url?: string | null;
          role?: RolUsuario;
          created_at?: string;
        };
        Relationships: [];
      };
      equipment: {
        Row: {
          id: string;
          name: string;
          description: string;
          image_url: string;
          total_units: number;
          available_units: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description: string;
          image_url: string;
          total_units: number;
          available_units?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string;
          image_url?: string;
          total_units?: number;
          available_units?: number;
          created_at?: string;
        };
        Relationships: [];
      };
      loans: {
        Row: {
          id: string;
          student_id: string;
          equipment_id: string;
          requested_at: string;
          due_at: string;
          status: EstadoPrestamo;
          processed_at: string | null;
          returned_at: string | null;
        };
        Insert: {
          id?: string;
          student_id: string;
          equipment_id: string;
          requested_at?: string;
          due_at: string;
          status?: EstadoPrestamo;
          processed_at?: string | null;
          returned_at?: string | null;
        };
        Update: {
          id?: string;
          student_id?: string;
          equipment_id?: string;
          requested_at?: string;
          due_at?: string;
          status?: EstadoPrestamo;
          processed_at?: string | null;
          returned_at?: string | null;
        };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: {
      request_loan: {
        Args: { p_equipment_id: string };
        Returns: string;
      };
      review_loan: {
        Args: { p_loan_id: string; p_decision: 'approved' | 'rejected' };
        Returns: undefined;
      };
      return_loan: {
        Args: { p_loan_id: string };
        Returns: undefined;
      };
    };
    Enums: { [_ in never]: never };
    CompositeTypes: { [_ in never]: never };
  };
}