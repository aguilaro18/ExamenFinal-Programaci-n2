import type { EstadoPrestamo, RolUsuario } from '../services/supabase';

export interface PerfilUsuario {
  id: string;
  full_name: string;
  carnet: string;
  career: string;
  photo_url: string | null;
  role: RolUsuario;
  created_at: string;
}

export interface Equipo {
  id: string;
  name: string;
  description: string;
  image_url: string;
  total_units: number;
  available_units: number;
  created_at: string;
}

export interface Prestamo {
  id: string;
  student_id: string;
  equipment_id: string;
  requested_at: string;
  due_at: string;
  status: EstadoPrestamo;
  processed_at: string | null;
  returned_at: string | null;
  student?: Pick<PerfilUsuario, 'full_name' | 'carnet'>;
  equipment?: Pick<Equipo, 'name'>;
}
