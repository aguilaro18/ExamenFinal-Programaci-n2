import { useState } from 'react';
import {
  ActivityIndicator, Image, KeyboardAvoidingView, Platform, Pressable,
  ScrollView, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { RolUsuario } from '../services/supabase';
import { seleccionarFoto } from '../services/imagenes';
import { subirFotoPerfil } from '../services/prestamos';
import { supabase } from '../services/supabase';
import { limpiarRolEsperado } from '../services/rolAcceso';
import { estilos } from '../theme/estilos';

interface Props {
  errorAcceso: string | null;
  onRoleSelected: (role: RolUsuario) => void;
}

export function AccesoScreen({ errorAcceso, onRoleSelected }: Props) {
  const [registro, setRegistro] = useState(false);
  const [rolAcceso, setRolAcceso] = useState<RolUsuario>('student');
  const [nombre, setNombre] = useState('');
  const [carnet, setCarnet] = useState('');
  const [carrera, setCarrera] = useState('');
  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [foto, setFoto] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [procesando, setProcesando] = useState(false);

  async function escogerFoto() {
    try {
      setError(null);
      const uri = await seleccionarFoto();
      if (uri) setFoto(uri);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo seleccionar la foto');
    }
  }

  async function enviar() {
    setError(null);
    setMensaje(null);
    setProcesando(true);
    try {
      const email = correo.trim().toLowerCase();
      if (!email || !contrasena) throw new Error('Ingresa tu correo y contraseña.');

      if (registro) {
        onRoleSelected('student');
        if (!nombre.trim() || !carnet.trim() || !carrera.trim()) {
          throw new Error('Completa tu nombre, carnet universitario y carrera.');
        }
        if (contrasena.length < 6) throw new Error('La contraseña debe tener al menos 6 caracteres.');

        const { data, error: errorRegistro } = await supabase.auth.signUp({
          email,
          password: contrasena,
          options: {
            data: {
              full_name: nombre.trim(),
              carnet: carnet.trim(),
              career: carrera.trim(),
            },
          },
        });
        if (errorRegistro) throw new Error(errorRegistro.message);

        if (data.session && data.user && foto) {
          const fotoUrl = await subirFotoPerfil(data.user.id, foto);
          const { error: errorFoto } = await supabase.from('profiles')
            .update({ photo_url: fotoUrl }).eq('id', data.user.id);
          if (errorFoto) throw new Error(errorFoto.message);
        }
        if (!data.session) {
          limpiarRolEsperado();
          setMensaje(`Tu cuenta fue creada. Confirma tu correo y luego inicia sesión.${
            foto ? ' Después podrás agregar la foto desde Mi perfil.' : ''
          }`);
        }
      } else {
        onRoleSelected(rolAcceso);
        const { error: errorAcceso } = await supabase.auth.signInWithPassword({
          email,
          password: contrasena,
        });
        if (errorAcceso) throw new Error(errorAcceso.message);
      }
    } catch (e) {
      limpiarRolEsperado();
      setError(e instanceof Error ? e.message : 'Ocurrió un error inesperado');
    } finally {
      setProcesando(false);
    }
  }

  function cambiarModo() {
    setRegistro(!registro);
    setError(null);
    setMensaje(null);
  }

  return (
    <SafeAreaView style={estilos.pantalla}>
      <KeyboardAvoidingView
        style={estilos.pantalla}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={estilos.acceso} keyboardShouldPersistTaps="handled">
        <Text style={estilos.marca}>LABORATORIOS UNIVERSITARIOS</Text>
        <Text style={estilos.titulo}>{registro ? 'Crea tu cuenta' : 'Préstamo de equipos'}</Text>
        <Text style={estilos.descripcion}>
          {registro
            ? 'Regístrate como estudiante para consultar y solicitar equipos de laboratorio.'
            : 'Inicia sesión para consultar el equipo disponible en tus laboratorios.'}
        </Text>

        {!registro && (
          <>
            <Text style={estilos.etiqueta}>Tipo de acceso</Text>
            <View style={estilos.navegacion}>
              {([
                ['student', 'Estudiante'],
                ['admin', 'Administrador'],
              ] as const).map(([role, label]) => (
                <Pressable key={role} onPress={() => setRolAcceso(role)}
                  style={[estilos.pestaña, rolAcceso === role && estilos.pestañaActiva]}>
                  <Text style={[estilos.pestañaTexto, rolAcceso === role && estilos.pestañaTextoActiva]}>
                    {label}
                  </Text>
                </Pressable>
              ))}
            </View>
            {rolAcceso === 'admin' && (
              <Text style={estilos.aviso}>
                El acceso de administrador requiere una cuenta autorizada por la universidad.
              </Text>
            )}
          </>
        )}

        {registro && (
          <>
            <Text style={estilos.etiqueta}>Nombre completo</Text>
            <TextInput value={nombre} onChangeText={setNombre} placeholder="Tu nombre y apellidos"
              autoCapitalize="words" style={estilos.input} />
            <Text style={estilos.etiqueta}>Carnet universitario</Text>
            <TextInput value={carnet} onChangeText={setCarnet} placeholder="Número de carnet"
              autoCapitalize="characters" style={estilos.input} />
            <Text style={estilos.etiqueta}>Carrera</Text>
            <TextInput value={carrera} onChangeText={setCarrera} placeholder="Nombre de tu carrera"
              style={estilos.input} />
            <Text style={estilos.etiqueta}>Foto del estudiante (opcional)</Text>
            <View style={[estilos.fila, { marginBottom: 14 }]}>
              {foto
                ? <Image source={{ uri: foto }} style={estilos.avatar} />
                : <View style={estilos.avatarPlaceholder}><Text style={estilos.suave}>Sin foto</Text></View>}
              <Pressable onPress={escogerFoto} style={[estilos.botonSecundario, estilos.accion]}>
                <Text style={estilos.botonSecundarioTexto}>{foto ? 'Cambiar foto' : 'Seleccionar foto'}</Text>
              </Pressable>
            </View>
          </>
        )}

        <Text style={estilos.etiqueta}>Correo electrónico</Text>
        <TextInput value={correo} onChangeText={setCorreo} placeholder="nombre@universidad.edu"
          autoCapitalize="none" autoCorrect={false} keyboardType="email-address"
          textContentType="emailAddress" style={estilos.input} />
        <Text style={estilos.etiqueta}>Contraseña</Text>
        <TextInput value={contrasena} onChangeText={setContrasena} placeholder="Mínimo 6 caracteres"
          secureTextEntry textContentType={registro ? 'newPassword' : 'password'}
          style={estilos.input} />

        {(error || errorAcceso) && <Text style={estilos.error}>{error ?? errorAcceso}</Text>}
        {mensaje && <Text style={estilos.aviso}>{mensaje}</Text>}

        <Pressable onPress={enviar} disabled={procesando} style={[estilos.boton, procesando && { opacity: 0.65 }]}>
          {procesando
            ? <ActivityIndicator color="#fff" />
            : <Text style={estilos.botonTexto}>{registro ? 'Crear cuenta de estudiante' : 'Iniciar sesión'}</Text>}
        </Pressable>
        {(registro || rolAcceso === 'student') && (
          <Pressable onPress={cambiarModo} disabled={procesando}>
            <Text style={estilos.enlace}>
              {registro ? '¿Ya tienes una cuenta? Inicia sesión' : '¿Eres estudiante nuevo? Regístrate'}
            </Text>
          </Pressable>
        )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
