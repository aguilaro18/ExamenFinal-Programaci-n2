import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { PerfilUsuario, Prestamo } from '../models/Prestamo';
import { listarPrestamosAdministrador, marcarDevuelto, revisarPrestamo } from '../services/prestamos';
import { supabase } from '../services/supabase';
import { estilos } from '../theme/estilos';
import { colores } from '../theme/tokens';

type Seccion = 'solicitudes' | 'activos' | 'reportes';

function mostrarFecha(fecha: string): string {
  return new Date(fecha).toLocaleDateString('es-GT', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function AdministradorScreen({ perfil }: { perfil: PerfilUsuario }) {
  const [seccion, setSeccion] = useState<Seccion>('solicitudes');
  const [prestamos, setPrestamos] = useState<Prestamo[]>([]);
  const [cargando, setCargando] = useState(true);
  const [ocupado, setOcupado] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mensaje, setMensaje] = useState<string | null>(null);

  async function cargarPrestamos() {
    try {
      setError(null);
      setPrestamos(await listarPrestamosAdministrador());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudieron cargar los préstamos');
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => { void cargarPrestamos(); }, []);

  const pendientes = prestamos.filter((prestamo) => prestamo.status === 'pending');
  const activos = prestamos.filter((prestamo) => prestamo.status === 'approved');
  const reporte = useMemo(() => {
    const conteo = new Map<string, number>();
    for (const prestamo of prestamos) {
      const nombre = prestamo.equipment?.name ?? 'Equipo';
      conteo.set(nombre, (conteo.get(nombre) ?? 0) + 1);
    }
    return [...conteo.entries()].sort((a, b) => b[1] - a[1]);
  }, [prestamos]);

  async function procesar(id: string, accion: 'approved' | 'rejected' | 'returned') {
    try {
      setOcupado(id);
      setError(null);
      setMensaje(null);
      if (accion === 'returned') await marcarDevuelto(id);
      else await revisarPrestamo(id, accion);
      setMensaje(accion === 'approved' ? 'Solicitud aprobada.' :
        accion === 'rejected' ? 'Solicitud rechazada.' : 'Equipo marcado como devuelto.');
      await cargarPrestamos();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo actualizar el préstamo');
    } finally {
      setOcupado(null);
    }
  }

  async function cerrarSesion() {
    const { error: errorSesion } = await supabase.auth.signOut();
    if (errorSesion) setError(errorSesion.message);
  }

  function pestaña(id: Seccion, titulo: string) {
    return (
      <Pressable key={id} onPress={() => { setSeccion(id); setMensaje(null); setError(null); }}
        style={[estilos.pestaña, seccion === id && estilos.pestañaActiva]}>
        <Text style={[estilos.pestañaTexto, seccion === id && estilos.pestañaTextoActiva]}>{titulo}</Text>
      </Pressable>
    );
  }

  function tarjetaPrestamo(prestamo: Prestamo, acciones: boolean) {
    return (
      <View key={prestamo.id} style={estilos.tarjeta}>
        <View style={estilos.filaSeparada}>
          <Text style={[estilos.subtitulo, { flex: 1, marginBottom: 0 }]}>
            {prestamo.equipment?.name ?? 'Equipo'}
          </Text>
          <Text style={estilos.etiquetaEstado}>{prestamo.status === 'pending' ? 'Pendiente' : 'Aprobado'}</Text>
        </View>
        <Text style={[estilos.texto, { marginTop: 10 }]}>{prestamo.student?.full_name ?? 'Estudiante'}</Text>
        <Text style={estilos.suave}>Carnet: {prestamo.student?.carnet ?? '—'}</Text>
        <Text style={[estilos.suave, { marginTop: 6 }]}>Solicitud: {mostrarFecha(prestamo.requested_at)}</Text>
        <Text style={estilos.suave}>Devolución prevista: {mostrarFecha(prestamo.due_at)}</Text>
        {acciones && (
          <View style={[estilos.fila, { marginTop: 14 }]}>
            {prestamo.status === 'pending' ? (
              <>
                <Pressable onPress={() => { void procesar(prestamo.id, 'approved'); }}
                  disabled={ocupado === prestamo.id} style={[estilos.boton, estilos.accion]}>
                  <Text style={estilos.botonTexto}>{ocupado === prestamo.id ? '...' : 'Aprobar'}</Text>
                </Pressable>
                <Pressable onPress={() => { void procesar(prestamo.id, 'rejected'); }}
                  disabled={ocupado === prestamo.id} style={[estilos.botonSecundario, estilos.accion]}>
                  <Text style={estilos.botonTextoPeligro}>Rechazar</Text>
                </Pressable>
              </>
            ) : (
              <Pressable onPress={() => { void procesar(prestamo.id, 'returned'); }}
                disabled={ocupado === prestamo.id} style={[estilos.boton, estilos.accion]}>
                <Text style={estilos.botonTexto}>
                  {ocupado === prestamo.id ? 'Guardando…' : 'Marcar como devuelto'}
                </Text>
              </Pressable>
            )}
          </View>
        )}
      </View>
    );
  }

  return (
    <SafeAreaView style={estilos.pantalla}>
    <ScrollView style={estilos.pantalla} contentContainerStyle={estilos.contenido}>
      <View style={estilos.filaSeparada}>
        <View style={{ flex: 1 }}>
          <Text style={estilos.marca}>ADMINISTRACIÓN DE LABORATORIOS</Text>
          <Text style={[estilos.titulo, { fontSize: 24 }]}>Hola, {perfil.full_name}</Text>
        </View>
        <Pressable onPress={cerrarSesion}>
          <Text style={estilos.botonSecundarioTexto}>Salir</Text>
        </Pressable>
      </View>
      <View style={estilos.navegacion}>
        {pestaña('solicitudes', `Solicitudes${pendientes.length ? ` · ${pendientes.length}` : ''}`)}
        {pestaña('activos', `Activos · ${activos.length}`)}
        {pestaña('reportes', 'Reportes')}
      </View>

      {error && <Text style={estilos.error}>{error}</Text>}
      {mensaje && <Text style={estilos.aviso}>{mensaje}</Text>}
      {cargando
        ? <ActivityIndicator color={colores.primario} size="large" />
        : seccion === 'solicitudes'
          ? (
            <View>
              <Text style={estilos.subtitulo}>Solicitudes pendientes</Text>
              {pendientes.length
                ? pendientes.map((prestamo) => tarjetaPrestamo(prestamo, true))
                : <Text style={estilos.vacio}>No hay solicitudes pendientes de revisión.</Text>}
            </View>
          )
          : seccion === 'activos'
            ? (
              <View>
                <Text style={estilos.subtitulo}>Préstamos activos</Text>
                {activos.length
                  ? activos.map((prestamo) => tarjetaPrestamo(prestamo, true))
                  : <Text style={estilos.vacio}>No hay préstamos activos.</Text>}
              </View>
            )
            : (
              <View>
                <Text style={estilos.subtitulo}>Equipos más solicitados</Text>
                <View style={estilos.fila}>
                  <View style={[estilos.tarjeta, estilos.accion]}>
                    <Text style={estilos.suave}>Solicitudes registradas</Text>
                    <Text style={estilos.indicador}>{prestamos.length}</Text>
                  </View>
                  <View style={[estilos.tarjeta, estilos.accion]}>
                    <Text style={estilos.suave}>Préstamos activos</Text>
                    <Text style={estilos.indicador}>{activos.length}</Text>
                  </View>
                </View>
                {reporte.length
                  ? reporte.map(([nombre, total], indice) => (
                    <View key={nombre} style={[estilos.tarjeta, estilos.filaSeparada]}>
                      <View style={{ flex: 1 }}>
                        <Text style={estilos.suave}>#{indice + 1}</Text>
                        <Text style={estilos.texto}>{nombre}</Text>
                      </View>
                      <Text style={estilos.indicador}>{total}</Text>
                    </View>
                  ))
                  : <Text style={estilos.vacio}>Todavía no hay solicitudes para generar un reporte.</Text>}
              </View>
            )}
    </ScrollView>
    </SafeAreaView>
  );
}
