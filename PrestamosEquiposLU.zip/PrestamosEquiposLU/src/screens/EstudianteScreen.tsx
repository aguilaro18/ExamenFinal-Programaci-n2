import { useEffect, useState } from 'react';
import {
  ActivityIndicator, Image, Pressable, ScrollView, Text, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { Equipo, PerfilUsuario, Prestamo } from '../models/Prestamo';
import { seleccionarFoto } from '../services/imagenes';
import {
  listarEquipos, listarPrestamosEstudiante, obtenerPerfil, solicitarPrestamo, subirFotoPerfil,
} from '../services/prestamos';
import { supabase } from '../services/supabase';
import { estilos } from '../theme/estilos';
import { colores } from '../theme/tokens';

type Seccion = 'catalogo' | 'prestamos' | 'perfil';

function mostrarFecha(fecha: string): string {
  return new Date(fecha).toLocaleDateString('es-GT', { year: 'numeric', month: 'short', day: 'numeric' });
}

function estadoEnEspanol(estado: Prestamo['status']): string {
  const nombres: Record<Prestamo['status'], string> = {
    pending: 'Pendiente',
    approved: 'Aprobado',
    rejected: 'Rechazado',
    returned: 'Devuelto',
  };
  return nombres[estado];
}

export function EstudianteScreen({ perfil }: { perfil: PerfilUsuario }) {
  const [seccion, setSeccion] = useState<Seccion>('catalogo');
  const [equipos, setEquipos] = useState<Equipo[]>([]);
  const [prestamos, setPrestamos] = useState<Prestamo[]>([]);
  const [cargando, setCargando] = useState(true);
  const [ocupado, setOcupado] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [fotoUrl, setFotoUrl] = useState(perfil.photo_url);

  async function cargarDatos() {
    try {
      setError(null);
      const [listaEquipos, listaPrestamos] = await Promise.all([
        listarEquipos(),
        listarPrestamosEstudiante(perfil.id),
      ]);
      setEquipos(listaEquipos);
      setPrestamos(listaPrestamos);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudieron cargar los datos');
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => { void cargarDatos(); }, [perfil.id]);

  async function pedirPrestamo(equipo: Equipo) {
    try {
      setOcupado(equipo.id);
      setError(null);
      setMensaje(null);
      await solicitarPrestamo(equipo.id);
      setMensaje('Solicitud enviada. La fecha límite se calcula a 3 días desde hoy.');
      await cargarDatos();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo solicitar el préstamo');
    } finally {
      setOcupado(null);
    }
  }

  async function actualizarFoto() {
    try {
      setError(null);
      const uri = await seleccionarFoto();
      if (!uri) return;
      setOcupado('foto');
      const nuevaUrl = await subirFotoPerfil(perfil.id, uri);
      const { error: errorPerfil } = await supabase.from('profiles')
        .update({ photo_url: nuevaUrl }).eq('id', perfil.id);
      if (errorPerfil) throw new Error(errorPerfil.message);
      setFotoUrl(nuevaUrl);
      setMensaje('Foto de perfil actualizada.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo actualizar la foto');
    } finally {
      setOcupado(null);
    }
  }

  async function cerrarSesion() {
    const { error: errorSesion } = await supabase.auth.signOut();
    if (errorSesion) setError(errorSesion.message);
  }

  function navegar(nuevaSeccion: Seccion) {
    setSeccion(nuevaSeccion);
    setError(null);
    setMensaje(null);
    if (nuevaSeccion === 'perfil') {
      obtenerPerfil(perfil.id).then((actualizado) => {
        if (actualizado) setFotoUrl(actualizado.photo_url);
      }).catch((e: unknown) => {
        setError(e instanceof Error ? e.message : 'No se pudo actualizar el perfil');
      });
    }
  }

  return (
    <SafeAreaView style={estilos.pantalla}>
    <ScrollView style={estilos.pantalla} contentContainerStyle={estilos.contenido}>
      <View style={estilos.filaSeparada}>
        <View style={{ flex: 1 }}>
          <Text style={estilos.marca}>PORTAL DEL ESTUDIANTE</Text>
          <Text style={[estilos.titulo, { fontSize: 24 }]}>{perfil.full_name}</Text>
        </View>
        <Pressable onPress={cerrarSesion} accessibilityRole="button">
          <Text style={estilos.botonSecundarioTexto}>Salir</Text>
        </Pressable>
      </View>
      <View style={estilos.navegacion}>
        {([
          ['catalogo', 'Catálogo'],
          ['prestamos', 'Mis préstamos'],
          ['perfil', 'Mi perfil'],
        ] as const).map(([id, titulo]) => (
          <Pressable key={id} onPress={() => navegar(id)}
            style={[estilos.pestaña, seccion === id && estilos.pestañaActiva]}>
            <Text style={[estilos.pestañaTexto, seccion === id && estilos.pestañaTextoActiva]}>{titulo}</Text>
          </Pressable>
        ))}
      </View>

      {error && <Text style={estilos.error}>{error}</Text>}
      {mensaje && <Text style={estilos.aviso}>{mensaje}</Text>}
      {cargando
        ? <ActivityIndicator color={colores.primario} size="large" />
        : seccion === 'catalogo'
          ? (
            <View>
              <Text style={estilos.subtitulo}>Equipos de laboratorio</Text>
              {equipos.length === 0
                ? <Text style={estilos.vacio}>Todavía no hay equipos publicados.</Text>
                : equipos.map((equipo) => (
                  <View key={equipo.id} style={estilos.tarjeta}>
                    <Image source={{ uri: equipo.image_url }} style={estilos.imagenEquipo} resizeMode="cover" />
                    <View style={[estilos.filaSeparada, { marginBottom: 6 }]}>
                      <Text style={[estilos.subtitulo, { flex: 1, marginBottom: 0 }]}>{equipo.name}</Text>
                      <Text style={estilos.etiquetaEstado}>
                        {equipo.available_units > 0 ? `${equipo.available_units} disponible(s)` : 'No disponible'}
                      </Text>
                    </View>
                    <Text style={[estilos.texto, { marginBottom: 14 }]}>{equipo.description}</Text>
                    <Pressable disabled={equipo.available_units === 0 || ocupado === equipo.id}
                      onPress={() => { void pedirPrestamo(equipo); }}
                      style={[estilos.boton, (equipo.available_units === 0 || ocupado === equipo.id) && { opacity: 0.55 }]}>
                      {ocupado === equipo.id
                        ? <ActivityIndicator color="#fff" />
                        : <Text style={estilos.botonTexto}>Solicitar préstamo</Text>}
                    </Pressable>
                  </View>
                ))}
            </View>
          )
          : seccion === 'prestamos'
            ? (
              <View>
                <Text style={estilos.subtitulo}>Mis solicitudes y préstamos</Text>
                {prestamos.length === 0
                  ? <Text style={estilos.vacio}>Aún no has solicitado equipos.</Text>
                  : prestamos.map((prestamo) => (
                    <View key={prestamo.id} style={estilos.tarjeta}>
                      <View style={estilos.filaSeparada}>
                        <Text style={[estilos.subtitulo, { flex: 1, marginBottom: 0 }]}>
                          {prestamo.equipment?.name ?? 'Equipo'}
                        </Text>
                        <Text style={estilos.etiquetaEstado}>{estadoEnEspanol(prestamo.status)}</Text>
                      </View>
                      <Text style={[estilos.suave, { marginTop: 10 }]}>Solicitud: {mostrarFecha(prestamo.requested_at)}</Text>
                      <Text style={estilos.suave}>Devolución prevista: {mostrarFecha(prestamo.due_at)}</Text>
                    </View>
                  ))}
              </View>
            )
            : (
              <View style={estilos.tarjeta}>
                <Text style={estilos.subtitulo}>Perfil de estudiante</Text>
                <View style={[estilos.fila, { marginBottom: 16 }]}>
                  {fotoUrl
                    ? <Image source={{ uri: fotoUrl }} style={estilos.avatar} />
                    : <View style={estilos.avatarPlaceholder}><Text style={estilos.suave}>Sin foto</Text></View>}
                  <Pressable onPress={() => { void actualizarFoto(); }} disabled={ocupado === 'foto'}
                    style={[estilos.botonSecundario, estilos.accion]}>
                    <Text style={estilos.botonSecundarioTexto}>
                      {ocupado === 'foto' ? 'Guardando…' : 'Agregar o cambiar foto'}
                    </Text>
                  </Pressable>
                </View>
                <Text style={estilos.etiqueta}>Nombre completo</Text>
                <Text style={[estilos.texto, { marginBottom: 12 }]}>{perfil.full_name}</Text>
                <Text style={estilos.etiqueta}>Carnet universitario</Text>
                <Text style={[estilos.texto, { marginBottom: 12 }]}>{perfil.carnet}</Text>
                <Text style={estilos.etiqueta}>Carrera</Text>
                <Text style={estilos.texto}>{perfil.career}</Text>
              </View>
            )}
    </ScrollView>
    </SafeAreaView>
  );
}
