export const colores = {
  primario: '#2457c5',
  acento: '#16a394',
  fondo: '#f6f7fb',
  superficie: '#ffffff',
  texto: '#1f2937',
  textoSuave: '#6b7280',
  borde: '#e5e7eb',
  error: '#c62828',
  blanco: '#ffffff',
} as const;
